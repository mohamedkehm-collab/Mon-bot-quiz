# Guide d'installation — Bot Quiz WhatsApp

Ce guide t'explique comment mettre ton bot en ligne, **entièrement depuis ton téléphone**, sans avoir besoin d'un ordinateur connecté à internet.

Tu n'as rien à coder. Tu vas juste créer 2 comptes gratuits et suivre les étapes.

---

## Étape 1 — Remplir tes questions

1. Ouvre le fichier **questions.xlsx** (avec l'appli Excel, Google Sheets ou WPS Office sur ton téléphone).
2. Des lignes d'exemple sont déjà remplies en jaune — regarde comment elles sont faites.
3. Remplis tes propres questions, une par ligne :
   - **Categorie** : le thème (Histoire, Sport, Musique...)
   - **Question** : la question
   - **BonneReponse** : la réponse correcte, en texte libre (ex : `Abidjan`, `1960`, `11`)
4. Enregistre le fichier (garde le nom `questions.xlsx`).

Il n'y a **pas de choix A/B/C/D** : les joueurs tapent directement leur réponse dans le chat. Le bot ignore les accents, les majuscules et la ponctuation, donc "abidjan", "Abidjan" ou "ABIDJAN !" sont tous acceptés.

---

## Étape 2 — Mettre le code en ligne (GitHub)

GitHub est un site gratuit où l'on dépose le code. On va s'en servir juste comme "stockage".

1. Va sur **github.com** depuis ton téléphone et crée un compte gratuit.
2. Une fois connecté, clique sur le bouton **"+"** en haut à droite → **"New repository"**.
3. Donne-lui un nom, par exemple `mon-bot-quiz`, laisse-le en **Public**, puis clique **Create repository**.
4. Sur la page du dépôt créé, clique sur **"Add file" → "Upload files"**.
5. Envoie TOUS les fichiers de ce dossier (`index.js`, `package.json`, `questions.xlsx`, et le dossier complet), puis clique **Commit changes**.

---

## Étape 3 — Héberger le bot (Render)

Render fait tourner le bot 24h/24 gratuitement.

1. Va sur **render.com** et crée un compte gratuit (tu peux te connecter directement avec ton compte GitHub, c'est plus simple).
2. Clique sur **"New +" → "Web Service"**.
3. Choisis le dépôt `mon-bot-quiz` que tu as créé à l'étape 2.
4. Dans les réglages, mets :
   - **Name** : ce que tu veux
   - **Runtime** : Node
   - **Build Command** : `npm install`
   - **Start Command** : `npm start`
   - **Instance Type** : Free
5. Descends jusqu'à **"Environment Variables"** → clique **Add Environment Variable** :
   - **Key** : `BOT_PHONE_NUMBER`
   - **Value** : ton numéro WhatsApp complet SANS le `+` (exemple : `2250700000000`)
6. Clique **Create Web Service**. Render va installer et démarrer le bot (ça prend 2-3 minutes).

**Par défaut, seul ton numéro (celui du bot) peut utiliser `!quiz`, `!stop` et `!sticker`** — les autres membres du groupe peuvent seulement répondre aux questions et taper `!score`/`!aide`.

Si tu veux aussi autoriser d'autres numéros (par exemple un co-animateur) à lancer le quiz, ajoute une deuxième variable d'environnement :
   - **Key** : `OWNER_NUMBERS`
   - **Value** : les numéros autorisés séparés par une virgule, sans le `+` (exemple : `2250700000000,2250100000000`)

---

## Étape 4 — Connecter ton numéro WhatsApp

1. Toujours sur Render, clique sur l'onglet **"Logs"** de ton service.
2. Attends qu'apparaisse un message avec un **code à 8 caractères** (ex: `ABCD-1234`).
3. Sur ton téléphone, ouvre **WhatsApp** → **Paramètres** → **Appareils connectés** → **Connecter un appareil**.
4. En bas, choisis **"Se connecter avec le numéro de téléphone à la place"**.
5. Entre le code affiché dans les logs de Render.
6. Attends quelques secondes → dans les logs, tu dois voir : `✅ Bot connecté à WhatsApp !`

🎉 Ton bot est en ligne, connecté à ton numéro, et tourne 24h/24 sans que ton téléphone reste allumé.

---

## Utiliser le bot

Dans un groupe ou une discussion privée, tape :

| Commande | Effet |
|---|---|
| `!quiz` | Démarre une série de **25 questions par défaut**, puis s'arrête et affiche le classement tout seul *(réservé à l'organisateur)* |
| `!quiz30` (ou tout autre nombre) | Démarre une série de **30 questions précises** (remplace le nombre par défaut) *(réservé à l'organisateur)* |
| (taper directement la réponse) | Le bot vérifie automatiquement — tu as **12 secondes**, **+10 points** si c'est correct |
| `!stop` | Arrête la série de questions **et affiche automatiquement le classement final** *(réservé à l'organisateur)* |
| `!score` | Affiche le classement — accessible à tous |
| réponds à une image avec `!sticker` | Transforme l'image en sticker *(réservé à l'organisateur)* |
| `!aide` | Rappelle les commandes — accessible à tous |

---

## Pour ajouter ou changer des questions plus tard

1. Modifie ton fichier `questions.xlsx`.
2. Sur GitHub, va dans ton dépôt → clique sur `questions.xlsx` → l'icône crayon (edit) n'existe pas pour les fichiers Excel : à la place, clique **"Add file" → "Upload files"** et renvoie le fichier modifié (il remplacera l'ancien).
3. Sur Render, ton service va se redéployer automatiquement (ou clique **"Manual Deploy" → "Deploy latest commit"**).

---

## Bon à savoir

- Cette méthode utilise ton **vrai numéro WhatsApp personnel** connecté comme un "appareil lié" (comme WhatsApp Web). Ce n'est pas la méthode officielle de Meta, donc évite un usage trop massif/agressif (des centaines de messages par minute) pour ne pas risquer une suspension.
- Si un jour le bot se déconnecte, retourne dans les logs Render : un nouveau code apparaîtra, à re-rentrer dans WhatsApp.
- Si tu bloques à une étape, dis-moi exactement où et je t'aide.
